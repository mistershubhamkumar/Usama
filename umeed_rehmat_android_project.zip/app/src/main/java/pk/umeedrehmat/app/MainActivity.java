package pk.umeedrehmat.app;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.*;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;

public class MainActivity extends Activity {
    int green=Color.rgb(12,75,57), gold=Color.rgb(194,155,72), cream=Color.rgb(250,247,238);
    LinearLayout page, content;
    MediaPlayer player;
    String[] surahs={"الفاتحہ","البقرہ","آل عمران","النساء","المائدہ","الانعام","الاعراف","الانفال","التوبہ","یونس","ھود","یوسف","الرعد","ابراہیم","الحجر","النحل","الاسراء","الکہف","مریم","طٰہٰ","الانبیاء","الحج","المؤمنون","النور","الفرقان","الشعراء","النمل","القصص","العنکبوت","الروم","لقمان","السجدہ","الاحزاب","سبا","فاطر","یس","الصافات","ص","الزمر","غافر","فصلت","الشوریٰ","الزخرف","الدخان","الجاثیہ","الاحقاف","محمد","الفتح","الحجرات","ق","الذاریات","الطور","النجم","القمر","الرحمٰن","الواقعہ","الحدید","المجادلہ","الحشر","الممتحنہ","الصف","الجمعہ","المنافقون","التغابن","الطلاق","التحریم","الملک","القلم","الحاقہ","المعارج","نوح","الجن","المزمل","المدثر","القیامہ","الدھر","المرسلات","النبا","النازعات","عبس","التکویر","الانفطار","المطففین","الانشقاق","البروج","الطارق","الاعلیٰ","الغاشیہ","الفجر","البلد","الشمس","اللیل","الضحیٰ","الشرح","التین","العلق","القدر","البینہ","الزلزال","العادیات","القارعہ","التکاثر","العصر","الہمزہ","الفیل","قریش","الماعون","الکوثر","الکافرون","النصر","المسد","الاخلاص","الفلق","الناس"};
    @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(14,12,14,12);return t;}
    void base(String title){
        page=new LinearLayout(this); page.setOrientation(1);page.setBackgroundColor(cream);
        TextView h=text(title,23,Color.WHITE);h.setGravity(Gravity.CENTER);h.setBackgroundColor(green);page.addView(h,new LinearLayout.LayoutParams(-1,-2));
        ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(1);content.setPadding(12,8,12,20);sc.addView(content);page.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(page);
    }
    void btn(String label,Runnable r){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));content.addView(b);b.setOnClickListener(v->r.run());}
    void showHome(){
        base("اسامہ — امیدِ رحمت");
        content.addView(text("السلام علیکم ورحمۃ اللہ وبرکاتہ\nقرآن، اذکار، تسبیح اور نماز کے اوقات ایک جگہ",18,green));
        btn("قرآنِ پاک — سنیں اور ڈاؤن لوڈ کریں",()->showQuran());
        btn("نماز کے اوقات (آن لائن)",()->showPrayer());
        btn("تسبیح",()->showTasbeeh());
        btn("روزانہ نیک اعمال",()->showDeeds());
        btn("ایپ کی معلومات اور اجازتیں",()->showInfo());
    }
    void showQuran(){
        base("قرآنِ پاک — آڈیو لائبریری");
        content.addView(text("قاری: مشاری العفاسی (آن لائن آڈیو)\nپہلی بار انٹرنیٹ ضروری ہے۔ ڈاؤن لوڈ مکمل ہونے کے بعد فائل ایپ کے اندر محفوظ رہے گی۔",15,green));
        for(int i=0;i<114;i++){
            final int n=i+1;
            LinearLayout row=new LinearLayout(this);row.setOrientation(1);row.setPadding(4,6,4,6);
            row.addView(text(String.format(Locale.US,"%03d۔ %s",n,surahs[i]),18,green));
            LinearLayout actions=new LinearLayout(this);
            Button play=new Button(this);play.setText("آن لائن سنیں");
            Button dl=new Button(this);dl.setText("ڈاؤن لوڈ");
            Button local=new Button(this);local.setText("محفوظ شدہ چلائیں");
            actions.addView(play,new LinearLayout.LayoutParams(0,-2,1));actions.addView(dl,new LinearLayout.LayoutParams(0,-2,1));actions.addView(local,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(actions);content.addView(row);
            String url="https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/"+n+".mp3";
            play.setOnClickListener(v->playUrl(url));
            dl.setOnClickListener(v->download(url,"Surah_"+n+".mp3"));
            local.setOnClickListener(v->playLocal("Surah_"+n+".mp3"));
        }
        btn("واپس",()->showHome());
    }
    void playUrl(String url){
        try{if(player!=null){player.release();player=null;} Toast.makeText(this,"آڈیو لوڈ ہو رہی ہے…",Toast.LENGTH_SHORT).show();
            player=new MediaPlayer();player.setDataSource(url);player.setOnPreparedListener(MediaPlayer::start);
            player.setOnErrorListener((mp,what,extra)->{Toast.makeText(this,"آڈیو نہیں چل سکی؛ انٹرنیٹ چیک کریں",Toast.LENGTH_LONG).show();return true;});player.prepareAsync();
        }catch(Exception e){Toast.makeText(this,"پلے بیک میں مسئلہ",Toast.LENGTH_SHORT).show();}
    }
    void download(String url,String name){
        try{
            DownloadManager dm=(DownloadManager)getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));
            req.setTitle(name);req.setDescription("امیدِ رحمت — قرآن آڈیو ڈاؤن لوڈ");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(this,Environment.DIRECTORY_MUSIC,name);
            dm.enqueue(req);Toast.makeText(this,"ڈاؤن لوڈ شروع ہو گیا۔ مکمل ہونے پر محفوظ آڈیو چلائیں دبائیں۔",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"ڈاؤن لوڈ شروع نہیں ہو سکا",Toast.LENGTH_SHORT).show();}
    }
    File audioFile(String name){return new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC),name);}
    void playLocal(String name){
        try{File f=audioFile(name);if(!f.exists()){Toast.makeText(this,"یہ سورۃ ابھی ڈاؤن لوڈ نہیں ہوئی",Toast.LENGTH_SHORT).show();return;}
            if(player!=null)player.release();player=new MediaPlayer();player.setDataSource(f.getAbsolutePath());player.setOnPreparedListener(MediaPlayer::start);player.prepareAsync();
        }catch(Exception e){Toast.makeText(this,"محفوظ آڈیو نہیں چل سکی",Toast.LENGTH_SHORT).show();}
    }
    void showPrayer(){
        base("نماز کے اوقات");
        content.addView(text("شہر/مقام کے مطابق آج کے اوقات حاصل کرنے کے لیے انٹرنیٹ اور لوکیشن اجازت درکار ہے۔ حساب: کراچی طریقہ، عصر حنفی۔ یہ عمومی حسابی اوقات ہیں؛ مقامی مسجد/مستند تقویم سے تصدیق کریں۔",15,green));
        btn("لوکیشن کی اجازت دیں اور اوقات دیکھیں",()->getPrayerTimes());
        btn("واپس",()->showHome());
    }
    void getPrayerTimes(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},22);return;}
        try{
            LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
            Location loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if(loc==null)loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(loc==null){content.addView(text("موجودہ مقام دستیاب نہیں۔ GPS آن کریں یا انٹرنیٹ کے ساتھ دوبارہ کوشش کریں۔",16,green));return;}
            String url="https://api.aladhan.com/v1/timings?latitude="+loc.getLatitude()+"&longitude="+loc.getLongitude()+"&method=1&school=1";
            content.addView(text("مقام حاصل ہو گیا۔ نماز کے اوقات کھولنے کے لیے نیچے بٹن دبائیں:",15,green));
            btn("آج کے اوقات آن لائن کھولیں",()->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))));
        }catch(Exception e){content.addView(text("لوکیشن حاصل نہیں ہو سکی۔",16,green));}
    }
    int count=0;
    void showTasbeeh(){base("ڈیجیٹل تسبیح");TextView c=text("0",42,gold);c.setGravity(Gravity.CENTER);content.addView(c);
        btn("سبحان اللہ — شمار بڑھائیں",()->{count++;c.setText(""+count);getPreferences(0).edit().putInt("tasbeeh",count).apply();});
        count=getPreferences(0).getInt("tasbeeh",0);c.setText(""+count);
        btn("شمار صفر کریں",()->{count=0;c.setText("0");getPreferences(0).edit().putInt("tasbeeh",0).apply();});btn("واپس",()->showHome());}
    void showDeeds(){base("روزانہ نیک اعمال");String[] acts={"پانچ نمازیں ادا کیں","قرآنِ پاک کی تلاوت","درود شریف","والدین کی خدمت","صدقہ/خیرات","غیبت سے بچا"};for(String a:acts){CheckBox cb=new CheckBox(this);cb.setText(a);cb.setTextColor(green);cb.setChecked(getPreferences(0).getBoolean(a,false));cb.setOnCheckedChangeListener((v,on)->getPreferences(0).edit().putBoolean(a,on).apply());content.addView(cb);}btn("واپس",()->showHome());}
    void showInfo(){base("اہم معلومات");content.addView(text("• آڈیو: Al Quran Cloud کے عوامی آڈیو CDN سے مشاری العفاسی کی سورۃ وار فائلیں۔\n• ڈاؤن لوڈ: Android DownloadManager کے ذریعے ایپ کے نجی Music فولڈر میں محفوظ ہوتی ہیں۔\n• نماز: کراچی طریقہ اور حنفی عصر کا حسابی لنک؛ یہ Dawat-e-Islami کا مصدقہ تقویم انجن نہیں۔\n• Google Sign-In ابھی شامل نہیں؛ اس کے لیے آپ کے اپنے Google OAuth Client ID اور SHA-1 کی ترتیب ضروری ہے۔\n• مکمل اذان الارم، قبلہ، کلاؤڈ بیک اپ اور سالانہ رپورٹس اس ورژن میں شامل نہیں۔\n• آڈیو استعمال کرتے وقت متعلقہ فراہم کنندہ کی شرائط/حقوق کا خیال رکھیں۔",15,green));btn("واپس",()->showHome());}
    @Override public void onDestroy(){if(player!=null){player.release();player=null;}super.onDestroy();}
}
