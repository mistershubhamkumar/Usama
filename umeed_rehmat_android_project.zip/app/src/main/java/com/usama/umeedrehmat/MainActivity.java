package com.usama.umeedrehmat;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int green = Color.rgb(16,61,50), gold = Color.rgb(197,164,91), cream = Color.rgb(246,242,232);
    LinearLayout root, content, nav;
    android.content.SharedPreferences prefs;
    Handler handler = new Handler();
    TextView clock;
    int tasbeeh = 0, target = 100;
    Runnable ticker = new Runnable(){ public void run(){
        if(clock != null) clock.setText(new SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(new Date()));
        handler.postDelayed(this,1000);
    }};
    public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("umeed",MODE_PRIVATE); tasbeeh=prefs.getInt("tasbeeh",0); showHome(); handler.post(ticker); }
    TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); t.setPadding(8,12,8,12); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); return b; }
    void base(String title){
        root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(cream);
        TextView head=text("بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ\\n"+title,22,Color.WHITE);
        head.setTypeface(null,Typeface.BOLD); head.setBackgroundColor(green); root.addView(head);
        content=new LinearLayout(this); content.setOrientation(1); content.setPadding(16,12,16,12);
        ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this); nav.setBackgroundColor(green);
        String[] tabs={"گھر","نماز","تسبیح","اعمال"};
        for(String x:tabs){ Button b=new Button(this); b.setText(x); b.setTextColor(Color.WHITE); b.setTextSize(12); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); b.setOnClickListener(v->{ if(x.equals("گھر"))showHome(); else if(x.equals("نماز"))showPrayer(); else if(x.equals("تسبیح"))showTasbeeh(); else showDeeds(); }); nav.addView(b,new LinearLayout.LayoutParams(0,WRAP_CONTENT,1)); }
        root.addView(nav); setContentView(root);
    }
    static final int WRAP_CONTENT=-2;
    void showHome(){
        base("اسامہ | امیدِ رحمت");
        clock=text("",34,green); content.addView(clock);
        content.addView(text("آپ کا ذاتی اسلامی ساتھی",18,green));
        content.addView(text("نماز • قرآن • ذکر و اذکار • نیک اعمال",15,green));
        content.addView(text("درودِ پاک",22,green));
        content.addView(text("صَلُّوا عَلَى الْحَبِيب صَلَّى اللّٰهُ تَعَالَى عَلَى مُحَمَّد",18,green));
        Button b=button("درود شریف پڑھ لیا"); b.setOnClickListener(v->Toast.makeText(this,"اللہ قبول فرمائے",Toast.LENGTH_SHORT).show()); content.addView(b);
        content.addView(text("یہ ابتدائی قابلِ تعمیر ورژن ہے۔ اگلے مرحلے میں مستند آف لائن آڈیو، قرآن اور نماز کے خودکار اوقات شامل ہوں گے۔",14,green));
    }
    void showPrayer(){
        base("نماز کا روزانہ ریکارڈ");
        String[] names={"فجر","ظہر","عصر","مغرب","عشاء"};
        for(String n:names){ CheckBox c=new CheckBox(this); c.setText(n+" ادا کی"); c.setTextSize(20); c.setTextColor(green); c.setChecked(prefs.getBoolean("prayer_"+n,false)); c.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean("prayer_"+n,on).apply()); content.addView(c); }
        content.addView(text("نوٹ: خودکار لوکیشن نماز اوقات اور اذان الارم اگلے مرحلے میں شامل ہوں گے۔",14,green));
    }
    void showTasbeeh(){
        base("ڈیجیٹل تسبیح");
        TextView count=text(String.valueOf(tasbeeh),54,green); content.addView(count);
        content.addView(text("سُبْحَانَ اللّٰهِ",26,green));
        Button add=button("تسبیح شمار کریں"); add.setOnClickListener(v->{tasbeeh++; prefs.edit().putInt("tasbeeh",tasbeeh).apply(); count.setText(""+tasbeeh);}); content.addView(add);
        Button reset=button("گنتی صفر کریں"); reset.setOnClickListener(v->{tasbeeh=0;prefs.edit().putInt("tasbeeh",0).apply();count.setText("0");}); content.addView(reset);
    }
    void showDeeds(){
        base("نیک اعمال");
        EditText e=new EditText(this); e.setHint("اپنا نیک عمل لکھیں"); content.addView(e);
        Button save=button("عمل محفوظ کریں"); save.setOnClickListener(v->{String s=e.getText().toString().trim(); if(!s.isEmpty()){String old=prefs.getString("deeds",""); prefs.edit().putString("deeds",old+(old.isEmpty()?"":"\\n")+s).apply(); e.setText(""); Toast.makeText(this,"عمل محفوظ ہوگیا",Toast.LENGTH_SHORT).show(); listDeeds();}}); content.addView(save);
        listDeeds();
    }
    void listDeeds(){ String d=prefs.getString("deeds",""); if(!d.isEmpty()) content.addView(text(d,18,green)); }
    @Override protected void onDestroy(){handler.removeCallbacks(ticker); super.onDestroy();}
}