اسامہ — امیدِ رحمت | Android Source Project

یہ ایک ابتدائی قابلِ تعمیر Android project ہے، مکمل تجارتی/مکمل اسلامی سوٹ نہیں۔
اس ورژن میں:
- اردو ہوم اسکرین
- 114 سورتوں کی آن لائن آڈیو فہرست
- آن لائن پلے بیک
- ہر سورۃ کے ساتھ Download بٹن؛ فائل ایپ کے نجی Music فولڈر میں محفوظ ہوتی ہے
- ڈاؤن لوڈ شدہ فائل دوبارہ چلانے کا بٹن
- لوکیشن اجازت لے کر کراچی طریقہ + حنفی عصر کے حسابی نماز اوقات کا AlAdhan لنک
- تسبیح کا مقامی شمار
- روزانہ اعمال کے چیک باکس (مقامی محفوظ کاری)
- GitHub Actions سے APK build

اہم حدود:
1) آڈیو لنک Al Quran Cloud کے CDN پر مبنی ہے؛ پہلی بار سننے/ڈاؤن لوڈ کرنے کے لیے انٹرنیٹ درکار ہے۔ ڈاؤن لوڈ کے بعد فائل آف لائن چلائی جا سکتی ہے۔
2) نماز کے اوقات کا حساب عمومی کراچی طریقہ/حنفی عصر ہے، Dawat-e-Islami کے مستند تقویم انجن کی ضمانت نہیں۔ مقامی مسجد کے اوقات سے تصدیق کریں۔
3) Google Sign-In، مکمل اذان الارم، قبلہ، قرآن عربی متن، بیک اپ/کلاؤڈ، ماہانہ/سالانہ رپورٹس اس ورژن میں شامل نہیں۔
4) Android 13+ پر notifications/alarms اور بعض ڈیوائسز پر battery restrictions کی اجازت الگ درکار ہو سکتی ہے۔

GitHub پر اپلوڈ:
A. GitHub.com پر نیا repository بنائیں، نام: umeed-rehmat-android
B. ZIP کو اپنے کمپیوٹر/موبائل میں extract کریں۔
C. repository میں Add file > Upload files سے extracted تمام فائلیں اپلوڈ کریں (ZIP کو بطور ZIP اپلوڈ نہ کریں)۔
D. Commit changes دبائیں۔
E. Actions ٹیب کھولیں۔ Android APK Build workflow خود چلنا چاہیے۔
F. کامیاب build کے بعد Actions > تازہ workflow run > Artifacts > app-debug-apk ڈاؤن لوڈ کریں۔
G. ZIP کے اندر موجود APK GitHub سے build ہوگا؛ یہاں سے براہ راست APK build ہونے کی ضمانت نہیں۔

اگر workflow شروع نہ ہو:
- Actions کو repository settings میں enable کریں۔
- app/src/main/java/.../MainActivity.java سمیت project کی تمام فائلیں root میں ہونی چاہئیں۔

APK انسٹال کرنے کے لیے APK فائل موبائل میں کھولیں اور Android کی اجازت کے مطابق Install unknown apps کی اجازت دیں۔
